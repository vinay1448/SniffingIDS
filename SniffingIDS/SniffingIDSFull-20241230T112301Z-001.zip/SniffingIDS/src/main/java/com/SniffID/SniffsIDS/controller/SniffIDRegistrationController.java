package com.SniffID.SniffsIDS.controller;


import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashSet;
import java.util.ResourceBundle;
import java.util.Set;

import javax.swing.JOptionPane;
import javax.swing.text.MaskFormatter;

import com.SniffID.SniffsIDS.util.dbConnection;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import com.SniffID.SniffsIDS.controller.BlowFishCipher;

public class SniffIDRegistrationController  {

	Connection conn = null;
	PreparedStatement pst = null;
	ResultSet rst = null;
	
	@FXML
	 final Button registernew = new Button(); 
	 final Button signinnew = new Button();
	
	@FXML
	TextField usernameid;
	
	@FXML
	TextField passwordid;
	
    @FXML
    TextField enterpasswordid;
        
    dbConnection dbc;
    
    Stage primaryStage = new Stage();

    ActionEvent event;
    
   
	public SniffIDRegistrationController()
	{
		dbc=new dbConnection();
	}
	
	public void dataAccessForm(ActionEvent event)
	{
		String name="";
		String pwd="";
	
		pwd = passwordid.getText();
		name = usernameid.getText();
		
			if(name.equals("") || pwd.equals(""))
			{
				showAlertMsg("Enter username and password",AlertType.ERROR);
			}
			else
			{
				if(userauthenticate(name,pwd))
				{
					try
					{
						dataAccess access = new dataAccess(name);
						access.fetchdata();
						
					}
					catch (Exception ex)
					{
						System.out.println("Following Error occured while retrieving the data: "+ex.toString()); 
					}
				}
		}
		
	}
	
	boolean userauthenticate(String userID,String passID)
	{
		dbc=new dbConnection();
		Connection link=dbc.getdbconnectionString();
		try
		{
			BlowFishCipher BF=new BlowFishCipher();
			pst=link.prepareStatement("SELECT userfinaldetailssubmit,passwordfinaldetailssubmit "+ "FROM sniffiduserdetails " + "WHERE 	userfinaldetailssubmit=?");
			pst.setString(1,userID);
			ResultSet rs;
			rs = pst.executeQuery();
			if (!rs.next()) 
			{
				showAlertMsg("Username does not exist",AlertType.ERROR);
				return false;
			} 
			else
			{
				String db_fetched_pwd=rs.getString("passwordfinaldetailssubmit");
				if(db_fetched_pwd.equals(BF.md5(passID)))
				{
					showAlertMsg("Great!!You are an authenticated User.\nThe data is stored in encrypted form.\nThe secret key is required to decode the data.\n\t\tPress OK to Proceed Further.",AlertType.INFORMATION);
					return true;
				}
				else
				{
					showAlertMsg("Incorrect password. Enter correct password",AlertType.ERROR);
				}

			}
		}
		catch (Exception ex)
		{
			System.out.println("The Following Error Occured while Checking User Handle and Password from the database: "+ex.toString());
		}
		return false;
		
	}
	
	public void dataEntryForm(ActionEvent event) throws IOException
	{
		TabPane paneses = (TabPane) FXMLLoader.load(getClass().getResource("/com/SniffID/SniffsIDS/views/SniffIDFacilityFinal.fxml"));
		Stage primaryStage = new Stage();
		Scene scenes = new Scene(paneses);
		primaryStage.setScene(scenes);
		primaryStage.show(); 
		
	}
	
	private void showAlertMsg(String msg, AlertType alertType)	{
		Alert alert = new Alert(alertType);
        alert.setTitle("Sniffing In Intrusion Detection");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
	}

}

