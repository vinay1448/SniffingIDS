/*
* To change this template, choose Tools | Templates
* and open the template in the editor.
*/
package com.SniffID.SniffsIDS.util;

import java.sql.*;
import javax.sql.*;
public class dbConnection 
{

	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	static final String DB_URL = "jdbc:mysql://localhost:3306/userdetails";

	static final String USER = "root";
	static final String PASS = "";
	Connection conn = null;
	Statement stmt = null;

	public Connection getdbconnectionString()
	{
		conn = null;
		stmt = null;
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
		}
		catch(SQLException se){
			
			se.printStackTrace();
		}catch(Exception e){
			
			e.printStackTrace();
		}finally{
			
		}
		return conn;
	}
	public void closeConnection(Connection link)
	{
		try{
			link.close();
		}
		catch(SQLException se)
		{
		}
		try{
			if(link!=null)
				link.close();
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
	}
}
