/*
* To change this template, choose Tools | Templates
* and open the template in the editor.
*/
package com.SniffID.SniffsIDS.controller;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import javax.imageio.ImageIO;
import javax.swing.*;


import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class BlowFishCipher 
{
	String download_secret_key_data="";
	SecretKey secretkey;
	void init()
	{
		while(true)
		{
			try
			{
				secretkey = KeyGenerator.getInstance("Blowfish").generateKey();
				byte[] encoded = secretkey.getEncoded();
				download_secret_key_data= new BigInteger(encoded).toString(16);
				if(download_secret_key_data.charAt(0)=='-')
				{}
				else
					break;
			}
			catch (Exception ex)
			{
				System.out.println("Following Error has occured while Generating Secret Key: "+ex.toString());
			}
		}
	}
	String[] Encrypt(String inputText[]) throws Exception 
	{
		
		File file = new File("D:\\secrets\\secretkey.txt"+inputText[0]+"_secretkey.txt");
		if (!file.exists())
			file.createNewFile();
		FileWriter fw = new FileWriter(file.getAbsoluteFile());
		BufferedWriter bw = new BufferedWriter(fw);
		bw.write(download_secret_key_data);
		bw.close();

		Cipher cipher = Cipher.getInstance("Blowfish");

		cipher.init(Cipher.ENCRYPT_MODE, secretkey);

		for(int i=0;i<inputText.length;i++)
		{
			byte[] encrypted = cipher.doFinal(inputText[i].getBytes());
			String encoded_encrypted_data= new BigInteger(encrypted).toString(16);
			inputText[i]=encoded_encrypted_data;
		}
		return inputText;
		

	}
	String[] decrypt(String datas[],String seckeybox,JFrame frame)
	{
		for(int i=1;i<(datas.length-1);++i)
		{
			byte[] encoded2 = new BigInteger(seckeybox, 16).toByteArray();
			SecretKey blowsecKey = new SecretKeySpec(encoded2, "Blowfish");
			try
			{

				Cipher cipher = Cipher.getInstance("Blowfish");
				cipher.init(Cipher.DECRYPT_MODE,blowsecKey);
				
				String encrypted_message_string = datas[i];
				byte[] encypted_msg_byte = new BigInteger(encrypted_message_string, 16).toByteArray();
				byte[] decrypted = cipher.doFinal(encypted_msg_byte);
				
				datas[i]=new String(decrypted);
			}
			catch (Exception ex)
			{
				JOptionPane.showMessageDialog(frame,"Sorry,the Data Cannot be decrypted as the secret key entered is Incorrect.");
				break;
			}
		}
		return datas;
	}
	
	
	public static String md5(String input) 
	{
		String md5 = null;
		if(null == input) 
			return null;
		try 
		{
			MessageDigest digest = MessageDigest.getInstance("MD5");
			digest.update(input.getBytes(), 0, input.length());
			md5 = new BigInteger(1, digest.digest()).toString(16);
		} 
		catch (NoSuchAlgorithmException e) 
		{
			e.printStackTrace();
		}
		return md5;
	}
}
