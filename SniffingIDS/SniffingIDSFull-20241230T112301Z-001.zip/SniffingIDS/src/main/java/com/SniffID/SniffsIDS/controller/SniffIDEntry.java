package com.SniffID.SniffsIDS.controller;


import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.SniffID.SniffsIDS.JNetWrapper;
import com.SniffID.SniffsIDS.controller.CaptureController;
import com.SniffID.SniffsIDS.controller.MainController;
import com.SniffID.SniffsIDS.util.dbConnection;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import com.SniffID.SniffsIDS.controller.BlowFishCipher;

public class SniffIDEntry {

	dbConnection dbc;
	PreparedStatement query = null;
	String user_id="NA";
        BlowFishCipher BF;
        TabPane paneentry;
        Tab userdetailstab, personallockertab, abouttab, packetsniffingtab;
        @FXML
    	Button submitdetailsfinal;
        @FXML
        Label usernamevisiblelabel, emailvisiblelabel, passwordvisiblelabel, enterpasswordvisiblelabel;
    	@FXML
    	TextField userfinaldetailssubmitid, emailfinaldetailssubmitid, passwordfinaldetailssubmitid, enterpasswordfinaldetailssubmitid;
    	@FXML
    	Label banknamevisiblelabel, bankpasswordvisiblelabel, banknumbervisiblelabel, bankcvvvisiblelabel, bankpinvisiblelabel;
    	@FXML
    	TextField usernamebankacctdetails, userbankpassworddetails, userbanknumdetails, usercvvdetails, userpincodedetails;
    	ActionEvent event;
    	@FXML
    	TabPane tabpaneses;
    	
    	 MainController mainController;
    	    public static CaptureController captureController;
    	    public static String selectedDevString="";
    	    public static Stage mainStage;
    	    Stage primaryStage = new Stage();
        
	public SniffIDEntry() throws IOException
	{
		dbc=new dbConnection();
        BF=new BlowFishCipher();
        BF.init();
    	tabpaneses = new TabPane();
    	tabpaneses.getSelectionModel().selectedItemProperty().addListener(
    			new ChangeListener<Tab>() {
    				 public void changed(ObservableValue<? extends Tab> ov, Tab t, Tab t1) {
 						
						 if(t1.equals(tabpaneses))
						 {
							 insertdataintodatabase(1);
						 }
						 else if(t.equals(tabpaneses))
						 {
							 insertdataintodatabase(1);
						 }
						 else
						 {
						 }
					 }}
				);
	}
	 String ismandatoryfield_completed()
     {
		    String usersubmitfinalfield = userfinaldetailssubmitid.getText().trim();
			String emailfinalsubmitfield = emailfinaldetailssubmitid.getText().trim();
			String passwordfinalsubs = passwordfinaldetailssubmitid.getText().trim();
			String entspassfinalsubs = enterpasswordfinaldetailssubmitid.getText().trim();
		 
         String ErrorMsg="";
      
         if(userfinaldetailssubmitid.getText().equals(""))
         {
             ErrorMsg=ErrorMsg+"UserName Should not be empty\n";
         }
         else
         {
             Connection link=dbc.getdbconnectionString();
             try
             {
                 query=link.prepareStatement("SELECT userfinaldetailssubmit "+ "FROM sniffiduserdetails " + "WHERE userfinaldetailssubmit=?");
                 query.setString(1,usersubmitfinalfield);
                 ResultSet rs;
                 rs =query.executeQuery();
                 if (rs.next()) 
                 {
                	 showAlertMsg("Name already exists",AlertType.ERROR);
                 } 
             }
             catch(Exception ex)
             {
                 System.out.println("Following Error Occured while Checking Duplicate UserName "+ex.toString());
             }
         }
         if((passwordfinalsubs.equals(entspassfinalsubs)) && (passwordfinalsubs.length() > 0 && entspassfinalsubs.length() > 0))
         {
         }
         else
         {
        	   ErrorMsg=ErrorMsg+"Enter password and Confirm password did not match.\n"; 
         }
         return ErrorMsg; 
     }
	
	 boolean insertdataintodatabase(int val)
		{
		
		 if(val == 1)
		 {
		        String user_id="NA";
				String db_user="NA",db_password="",db_enterpass="NA",db_email="NA", db_bankname="NA",db_bankpass="NA",db_banknumber="NA", db_bankcvv="NA",db_bankpin="NA";
				String fetchedata[]=new String[10];
				for(int i=0;i<fetchedata.length;++i)
					fetchedata[i]="NA";
			
				db_user=fetchedata[0]=userfinaldetailssubmitid.getText();
				db_email=fetchedata[1]=emailfinaldetailssubmitid.getText();
				db_password=fetchedata[2]=passwordfinaldetailssubmitid.getText();
				db_enterpass=fetchedata[3]=enterpasswordfinaldetailssubmitid.getText();
				db_bankname=fetchedata[4]=usernamebankacctdetails.getText();
				db_bankpass=fetchedata[5]=userbankpassworddetails.getText();
				db_banknumber=fetchedata[6]=userbanknumdetails.getText();
				db_bankcvv=fetchedata[7]=usercvvdetails.getText();
				db_bankpin=fetchedata[8]=userpincodedetails.getText();
				user_id=db_user;
				try
				{
					fetchedata=BF.Encrypt(fetchedata);
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
	                               
	                        }
				Connection link=dbc.getdbconnectionString();
				try
				{
					query=link.prepareStatement("Insert into sniffiduserdetails(userfinaldetailssubmit, emailfinaldetailssubmit, passwordfinaldetailssubmit, enterpasswordfinaldetailssubmit, banknamedetailssubmit, bankpassworddetailssubmit, banknumberdetailssubmit, bankcvvdetailssubmit, bankpindetailssubmit) "+" values (?,?,?,?,?,?,?,?,?)");
					query.setString(1,db_user);
					query.setString(2,fetchedata[1]);
					query.setString(3,BF.md5(db_password));
					query.setString(4,fetchedata[3]);
					query.setString(5, fetchedata[4]);
					query.setString(6, fetchedata[5]);
					query.setString(7, fetchedata[6]);
					query.setString(8, fetchedata[7]);
					query.setString(9, fetchedata[8]);
					
					int s =query.executeUpdate();
					if(s>0)
						System.out.println("The Information is successfully Update into database");
					else
						System.out.println("Oops!!an Internal Error has Occured while inserting the information into to the database.");
				}
				catch(Exception ex)
				{
					System.out.println("The Following Error Has Occured while Inserting Personal Information into database: "+ex.toString());
	                                return false;
	                        }
			}
	                return true;
		}
		
	
	public void handleUserDetailsAction(ActionEvent event)
	{
		 try
		 {
			 String errmsg=ismandatoryfield_completed();
             if(errmsg.length()>0)
             {
                showAlertMsg("The data cannot be inserted into database due to following Errors. Please fix them first (by clicking on User Credentials tab)before proceeding further",AlertType.ERROR);
             }
             else
             {
            	 if(insertdataintodatabase(1))
            	 {
                      File file = new File("D:\\secrets");
                     System.out.println();
                     showAlertMsg("Details inserted",AlertType.INFORMATION);
                     System.out.println("Data is Successfully stored in a database.\nPlease note: The Secret key is generated in following text file: "+file.getAbsoluteFile()+ "\\" + userfinaldetailssubmitid.getText()+"_secretkey.txt\nThe Secret Key in the text file will be used later for decoding the data.\nPlease Store it and Keep it safe!!");
                 }
            	 else
            	 {
            	 }
             } 
             }
		 catch(Exception e)
		 {
			 e.printStackTrace();
		 }
	}
	
	public void handlePacketSniffingAction(ActionEvent event) throws IOException
	{
		 JNetWrapper.init();
	        mainStage=primaryStage;
	        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/SniffID/SniffsIDS/views/main_window.fxml"));
	        Parent root = fxmlLoader.load();
	        mainController = fxmlLoader.getController();
	        mainStage.setTitle("IDS");
	        mainStage.setScene(new Scene(root));
	        mainStage.show();
	}
	
	
	private void showAlertMsg(String msg, AlertType alertType)	{
		Alert alert = new Alert(alertType);
        alert.setTitle("Sniffing In Intrusion Detection");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
	}
}
