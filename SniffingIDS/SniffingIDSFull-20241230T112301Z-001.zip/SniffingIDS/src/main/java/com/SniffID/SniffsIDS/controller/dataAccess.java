
package com.SniffID.SniffsIDS.controller;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

import com.SniffID.SniffsIDS.util.dbConnection;

import java.io.File;
import java.sql.*;
public class dataAccess extends WindowAdapter implements ActionListener
{
	
	dbConnection dbc;
	PreparedStatement query = null;
	String user_id="NA";

	JFrame frame;
	JPanel panel;
	JPanel panesfinal, paneslockerfinal;
	JTabbedPane tabpaneaccessfetch;
	JTextField secretfieldaccess;
	JLabel usernamevisiblelabel, emailvisiblelabel, infokeylabelfetch; 
	JLabel banknamevisiblelabel, bankpasswordvisiblelabel, banknumbervisiblelabel, bankcvvvisiblelabel, bankpinvisiblelabel;
	JButton decodeinfoid;
	
	public dataAccess(String uid)throws IOException
	{
		user_id=uid;
		dbc=new dbConnection();
		
		frame=new JFrame("Sniffing In Intrusion Detection");
		panel = new JPanel();
		panesfinal = new JPanel();
		paneslockerfinal = new JPanel();
		decodeinfoid = new JButton("Decrypt Data");
		infokeylabelfetch = new JLabel("Data is stored in encrypted form. Enter the secret key");
		secretfieldaccess = new JTextField(256);
		tabpaneaccessfetch = new JTabbedPane();
	
		frame.setSize(800, 700);
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(panel); 
		   
		panel.setBackground(Color.BLACK);
		panel.add(tabpaneaccessfetch);
		panel.setLayout(null);
		
		secretfieldaccess.setBounds(50,175,300,24);
		tabpaneaccessfetch.setBounds(50,145,700,450);
		tabpaneaccessfetch.setBackground(Color.DARK_GRAY);
		tabpaneaccessfetch.setForeground(Color.WHITE);
		
		decodeinfoid.setForeground(Color.WHITE);
		decodeinfoid.setBackground(Color.GRAY);
		decodeinfoid.setBounds(355,175,150,24);
		decodeinfoid.addActionListener(this);
	
		usernamevisiblelabel = new JLabel("Username");
		emailvisiblelabel = new JLabel("Email");
		panesfinal.add(usernamevisiblelabel);
		panesfinal.add(emailvisiblelabel);
		panesfinal.setBackground(Color.DARK_GRAY);
		panesfinal.setForeground(Color.WHITE);
		panesfinal.add(infokeylabelfetch);
		panesfinal.add(secretfieldaccess);
		panesfinal.add(decodeinfoid);
		panesfinal.setLayout(null);
		usernamevisiblelabel.setBounds(60,35, 400,24);
		usernamevisiblelabel.setForeground(Color.WHITE);
		emailvisiblelabel.setBounds(60,65, 400,24);
		infokeylabelfetch.setBounds(50,150, 650,24);
		infokeylabelfetch.setForeground(Color.WHITE);
		infokeylabelfetch.setBackground(Color.GRAY);
		emailvisiblelabel.setForeground(Color.WHITE);
		banknamevisiblelabel = new JLabel("Name");
		banknamevisiblelabel.setForeground(Color.WHITE);
		bankpasswordvisiblelabel=new JLabel("NetBanking Password");
		bankpasswordvisiblelabel.setForeground(Color.WHITE);
		banknumbervisiblelabel=new JLabel("Bank Account Number");
		banknumbervisiblelabel.setForeground(Color.WHITE);
		bankcvvvisiblelabel=new JLabel("CVV Number");
		bankcvvvisiblelabel.setForeground(Color.WHITE);
		bankpinvisiblelabel=new JLabel("Credit Card PinCode");
		bankpinvisiblelabel.setForeground(Color.WHITE);		
		paneslockerfinal.add(banknamevisiblelabel);
		paneslockerfinal.setBackground(Color.DARK_GRAY);
		paneslockerfinal.add(bankpasswordvisiblelabel);
		paneslockerfinal.add(banknumbervisiblelabel);
		paneslockerfinal.add(bankcvvvisiblelabel);
		paneslockerfinal.add(bankpinvisiblelabel);
		paneslockerfinal.setLayout(null);
		
		banknamevisiblelabel.setBounds(60,35, 400,24);
		bankpinvisiblelabel.setBounds(60,65,400,24);
		bankcvvvisiblelabel.setBounds(60,95,400,24);
		banknumbervisiblelabel.setBounds(60,125,400,24);
		bankpasswordvisiblelabel.setBounds(60,155,400,24);
		
		tabpaneaccessfetch.addTab("User Details", panesfinal);
		tabpaneaccessfetch.addTab("Personal Locker", paneslockerfinal);
		
	}
	public void actionPerformed(ActionEvent e)
	{
		 if(e.getSource() == decodeinfoid)
		 {
			 fetchdata();
		 }
	}

	public void fetchdata()
	{
		Connection link=dbc.getdbconnectionString();
		try
		{
			query=link.prepareStatement("SELECT userfinaldetailssubmit,emailfinaldetailssubmit, banknamedetailssubmit,bankpassworddetailssubmit,banknumberdetailssubmit,bankcvvdetailssubmit,bankpindetailssubmit "+ "FROM sniffiduserdetails " + "WHERE userfinaldetailssubmit=?");
			query.setString(1,user_id);
			ResultSet rs =query.executeQuery();
			if(rs.next())
			{
				String fetched_data[]=new String[8];
				fetched_data[7]="";
				String db_user=fetched_data[0]=rs.getString("userfinaldetailssubmit");
				String db_email=fetched_data[1]=rs.getString("emailfinaldetailssubmit");
				String db_bankname=fetched_data[2]=rs.getString("banknamedetailssubmit");
				String db_bankpass=fetched_data[3]=rs.getString("bankpassworddetailssubmit");
				String db_banknumber=fetched_data[4]=rs.getString("banknumberdetailssubmit");
				String db_bankcvv=fetched_data[5]=rs.getString("bankcvvdetailssubmit");
				String db_bankpin=fetched_data[6]=rs.getString("bankpindetailssubmit");
				
				if(secretfieldaccess.getText().length()>0)
				{
					BlowFishCipher BF=new BlowFishCipher();
					fetched_data=BF.decrypt(fetched_data, secretfieldaccess.getText(), frame);
					if(fetched_data[7].length()>0)
					{
						JOptionPane.showMessageDialog(frame,fetched_data[7]);
					}
				}
				usernamevisiblelabel.setText("Name:          " + db_user);
				emailvisiblelabel.setText("Email:              " + fetched_data[1]);
				banknamevisiblelabel.setText("Name:          " + fetched_data[2]);
				bankpasswordvisiblelabel.setText("NetBanking Password:             " + fetched_data[3]);
				banknumbervisiblelabel.setText("Bank Account Number:       " + fetched_data[4]);
				bankcvvvisiblelabel.setText("CVV Number:           " + fetched_data[5]);
				bankpinvisiblelabel.setText("Credit Card PinCode:               " + fetched_data[6]);
			}
			else
			{
				System.out.println("Record not found in database.");
			}
		}
		catch (Exception ex)
		{
			System.out.println("Error Occurs While Connecting with database: "+ex.toString());
		} 
	}
}